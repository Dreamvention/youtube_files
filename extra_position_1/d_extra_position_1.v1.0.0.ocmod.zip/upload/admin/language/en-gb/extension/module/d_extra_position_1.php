<?php

$_['heading_title'] = '<span style="color:#449DD0; font-weight:bold">Extra Position 1</span><span style="font-size:12px; color:#999"> by <a href="http://www.opencart.com/index.php?route=extension/extension&filter_username=Dreamvention" style="font-size:1em; color:#999" target="_blank">Dreamvention</a></span>';
$_['heading_title_main'] = 'Extra Position 1';
$_['text_module'] = 'Modules';
$_['text_edit'] = 'Adding Extra Positions';
$_['text_description'] = '
<div style="max-width:700px; margin:auto">
<h1>How Extra Position 1 is added</h1>
<p>Because OpenCart has hardcoded only 4 positions, you may experience the need to create your own positions. Luckily in the latest versions of OpenCart 2 and above it is relatively simple.</p>

<p>Here is a breakdown of the steps:</p>
<ul>
	<li>1. Add html code for new position to admin view;</li>
	<li>2. Add controller for new position in catalog;</li>
	<li>3. Add template for new position in catalog;</li>
	<li>4. Add php code to other controllers to load new position controller;</li>
	<li>5. Add the placeholder for the new position in the html view of your pages;</li>
</ul>
<br/>
<br/>
<h2>1. Add html code for new position to admin view</h2>

<p>In <b>admin/view/template/design/layout_form.twig</b> add new block of html code for the extra position. You can simply copy one from column-right and modify the code replacing <b>column-right</b> with <b>position_1</b>.</p><br>

<img src="view/image/d_extra_position_1/image1.png" class="img-responsive img-thumbnail">
<br/>
<br/>
<h2>2. Add controller for new position in catalog</h1>

In <span class="path">catalog/controller/common/</span> create a new file called <b>position_1.php</b> and copy the code from <b>column_right.php</b>. In the code replace <b>ColumnRight</b> with <b>Position1</b> and <b>column_right</b> with <b>position_1</b><br><br>

<img src="view/image/d_extra_position_1/image2.png" class="img-responsive img-thumbnail">
<br/>
<br/>
<h2>3. Add template for new position in catalog</h2>

<p>Create a template file <b>catalog/view/theme/default/template/common/position_1.twig</b> as a copy of <b>column_right.twig</b>. Edit the Html code to fit your needs (for example replace the id with <b>position_1</b> and <b>col-sm-3</b> with <b>col-sm-12</b>)<p><br>

<img src="view/image/d_extra_position_1/image3.png" class="img-responsive img-thumbnail">
<br/>
<br/>
<h2>4. Add php code to other controllers to load new position controller</h2>

<p>In all pages load the controller for the new position (for example in  <b>catalog/controller/common/home.php</b> load the new controller after <b>column_right</b>)<p><br>

<img src="view/image/d_extra_position_1/image4.png" class="img-responsive img-thumbnail">

<br/>
<br/>
<h2>5. Add the placeholder for the new position in the html view of your pages</h2>

<p>And in <b>catalog/view/theme/default/template/common/home.twig</b> add the placeholder php code display the new position.</p><br>
<img src="view/image/d_extra_position_1/image5.png" class="img-responsive img-thumbnail">
<br/><br/>
<p>For more information please contact our <a href="https://dreamvention.ee/support" target="_blank">support</a></p>
</div>


';