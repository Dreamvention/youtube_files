<?php
class ControllerExtensionModuleMSProductOption extends Controller {
    private $error = array();
    private $codename = 'ms_product_option';

    public function index() {
        $this->load->language('extension/module/ms_product_option');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');


        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('module_ms_product_option', $this->request->post);

            $this->session->data['success'] = $this->language->get('text_success');

            $this->load->model('setting/event');
            $this->model_setting_event->deleteEventByCode($this->codename);

            if($this->request->post['module_ms_product_option_status']){
                $this->model_setting_event->addEvent($this->codename, 'admin/model/catalog/product/editProduct/after', 'extension/module/ms_product_option/model_catalog_product_editProduct_after');
                $this->model_setting_event->addEvent($this->codename, 'admin/view/catalog/product_form/before', 'extension/module/ms_product_option/view_catalog_product_form_before');
            }

            $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
        }

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/ms_product_option', 'user_token=' . $this->session->data['user_token'], true)
        );

        $data['action'] = $this->url->link('extension/module/ms_product_option', 'user_token=' . $this->session->data['user_token'], true);

        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);

        if (isset($this->request->post['module_ms_product_option_status'])) {
            $data['module_ms_product_option_status'] = $this->request->post['module_ms_product_option_status'];
        } else {
            $data['module_ms_product_option_status'] = $this->config->get('module_ms_product_option_status');
        }

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/module/ms_product_option', $data));
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/module/ms_product_option')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        return !$this->error;
    }

    public function install(){
        $this->load->model('extension/module/ms_product_option');
        $this->model_extension_module_ms_product_option->installDatabase();
    }

    public function uninstall(){
        $this->load->model('extension/module/ms_product_option');
        $this->model_extension_module_ms_product_option->deleteDatabase();

        $this->load->model('setting/event');
        $this->model_setting_event->deleteEventByCode($this->codename);
    }

    //OC event to trigger update of slave products
    public function model_catalog_product_editProduct_after(&$route, &$data, &$output){
        $this->load->model('extension/module/ms_product_option');
        //check if master product
        if($this->model_extension_module_ms_product_option->isProductMaster($data[0])){
            $master_product_id = $data[0];
            //trigger update of slaves

            $this->model_extension_module_ms_product_option->updateProductsOptionsFromProductMaster($master_product_id);
        }else{
            $product_id = $data[0];
            $this->model_extension_module_ms_product_option->deleteProductFromProductMaster($product_id);
            if(!empty($data[1]['master_product_id'])){
                $master_product_id = $data[1]['master_product_id'];

                $this->model_extension_module_ms_product_option->addProductToProductMaster($product_id, $master_product_id);
            }
        }

        
    }
    public function view_catalog_product_form_before(&$route, &$data){
        if($data && isset($this->request->get['product_id'])){
            $product_id = $this->request->get['product_id'];
            $this->load->model('extension/module/ms_product_option');

            $product_info = $this->model_extension_module_ms_product_option->getMasterProductOfProduct($product_id);

            if($product_info){
                $data['master_product_id'] = $product_info['master_product_id'];
            }
        }
    }
    
}

