<?php
// Heading
$_['heading_title']    = '<span style="color:#449DD0; font-weight:bold">MS Product Option</span><span style="font-size:12px; color:#999"> by <a href="http://www.opencart.com/index.php?route=extension/extension&filter_username=Dreamvention" style="font-size:1em; color:#999" target="_blank">Dreamvention</a></span>';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified MS Product Option module!';
$_['text_edit']        = 'Edit MS Product Option Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify MS Product Option module!';