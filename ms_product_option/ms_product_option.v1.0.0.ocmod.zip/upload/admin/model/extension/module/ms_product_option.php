<?php
class ModelExtensionModuleMSProductOption extends Model {

    public function installDatabase() {
        $this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "ms_product_option` (
          `product_id` int(11) NOT NULL,
          `master_product_id` int(11) NOT NULL,
          PRIMARY KEY (`product_id`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;");
    }

    public function deleteDatabase() {
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "ms_product_option`");

    }

    public function isProductMaster($master_product_id) {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "ms_product_option` WHERE master_product_id = '" . (int)$master_product_id . "'");
        if($query->rows){
            return true;
        }else{
            return false;
        }
    }

    public function addProductToProductMaster($product_id, $master_product_id) {
        $this->db->query("INSERT INTO `" . DB_PREFIX . "ms_product_option` SET product_id = '" . (int)$product_id . "', master_product_id = '" . (int)$master_product_id . "'");
    }

    public function deleteProductFromProductMaster($product_id) {
        $this->db->query("DELETE FROM " . DB_PREFIX . "ms_product_option WHERE product_id = '" . (int)$product_id . "'");
    }

    public function getProductsOfProductMaster($master_product_id) {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "ms_product_option` msp2p LEFT JOIN " . DB_PREFIX . "product_description pd ON (msp2p.product_id = pd.product_id) WHERE pd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND msp2p.master_product_id = '".(int) $master_product_id. "'");
        return $query->rows;
    }

    public function getMasterProductOfProduct($product_id) {
        $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "ms_product_option` WHERE product_id = '".(int) $product_id. "'");
        return $query->row;
    }

    public function updateProductsOptionsFromProductMaster($master_product_id) {
        //get product master options
        $this->load->model('catalog/product');
        $data['product_option'] = $this->model_catalog_product->getProductOptions($master_product_id);

        //get list of products connected to product master
        $products = $this->getProductsOfProductMaster($master_product_id);

        //update options
        foreach($products as $product){
            $product_id = $product['product_id'];
            if (isset($data['product_option'])) {
                foreach ($data['product_option'] as $product_option) {
                    if ($product_option['type'] == 'select' || $product_option['type'] == 'radio' || $product_option['type'] == 'checkbox' || $product_option['type'] == 'image') {
                        if (isset($product_option['product_option_value'])) {
                            $this->db->query("INSERT INTO " . DB_PREFIX . "product_option SET product_id = '" . (int)$product_id . "', option_id = '" . (int)$product_option['option_id'] . "', required = '" . (int)$product_option['required'] . "'");

                            $product_option_id = $this->db->getLastId();

                            foreach ($product_option['product_option_value'] as $product_option_value) {
                                $this->db->query("INSERT INTO " . DB_PREFIX . "product_option_value SET product_option_id = '" . (int)$product_option_id . "', product_id = '" . (int)$product_id . "', option_id = '" . (int)$product_option['option_id'] . "', option_value_id = '" . (int)$product_option_value['option_value_id'] . "', quantity = '" . (int)$product_option_value['quantity'] . "', subtract = '" . (int)$product_option_value['subtract'] . "', price = '" . (float)$product_option_value['price'] . "', price_prefix = '" . $this->db->escape($product_option_value['price_prefix']) . "', points = '" . (int)$product_option_value['points'] . "', points_prefix = '" . $this->db->escape($product_option_value['points_prefix']) . "', weight = '" . (float)$product_option_value['weight'] . "', weight_prefix = '" . $this->db->escape($product_option_value['weight_prefix']) . "'");
                            }
                        }
                    } else {
                        $this->db->query("INSERT INTO " . DB_PREFIX . "product_option SET product_id = '" . (int)$product_id . "', option_id = '" . (int)$product_option['option_id'] . "', value = '" . $this->db->escape($product_option['value']) . "', required = '" . (int)$product_option['required'] . "'");
                    }
                }
            }
        }
    }
}